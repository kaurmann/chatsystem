<?php
session_start();
include 'conn.php';
$name=$_SESSION['admin'];


$fet=$conn->query("SELECT * FROM chat WHERE name='$name'");
$fetc=mysqli_fetch_array($fet);
$id=$fetc['id'];

if (isset($_POST['send'])) {
	$uid=$id;
	$rid=$_POST['name'];
	$msg=$_POST['msg'];
	$in=$conn->query("INSERT INTO `posts`(`uid`, `rid`, `msg`) VALUES ('$uid','$rid','$msg')");
	if ($in) {
		echo "<script>alert('send'); window.location.href='welcomechat.php';</script>";
	}else
	{
		echo "<script>alert('not send'); window.location.href='welcomechat.php';</script>";
	}
}



?>