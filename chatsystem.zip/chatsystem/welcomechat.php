<?php
session_start();
include 'conn.php';
$name=$_SESSION['admin'];


$fet=$conn->query("SELECT * FROM chat WHERE name='$name'");
$fetc=mysqli_fetch_array($fet);
$id=$fetc['id'];
?>
<!DOCTYPE html>
<html>
<head>
	<title>welcome chat section</title>
	<link rel="stylesheet"  href="style.css">
	<link rel="stylesheet" href="css/bootstrap.css"/>
<link rel="stylesheet" href="css/bootstrap.min.css"/>
<script src="js/bootstrap.js"></script>
<script src="js/jquery-1.11.0.js"></script>
<script src="js/bootstrap.min.js"></script>

</head>
<body>
		<p style="background-color: blue; text-transform: capitalize; color: white; padding: 10px; border-radius: 10px;"><?php echo $_SESSION['admin']; ?></p>

	<div class="output">
			<div class="send">
										<table>
												<tr style="color:gray; ">
													<td>name</td>
													<td>message</td>
													<td>date/time</td>
												</tr>
				<?php
					$send=$conn->query("SELECT * FROM posts WHERE uid='$id'");
						while ($gt=mysqli_fetch_array($send))
						{
							$rid=$gt['rid'];
							$msg=$gt['msg'];
							$date=$gt['date'];
							$print=$conn->query("SELECT * FROM chat WHERE id='$rid'");
							while ($gtt=mysqli_fetch_array($print)) {
								$name=$gtt['name'];
									?>
											<tr>
												<td><?php echo $name; ?></td>
												<td><?php echo $msg; ?></td>
												<td><?php echo $date;?></td>
											</tr>
									<?php
							}
						}
				?>
		</table>

			</div>

			<div class="receive">
				
									<table >
												<tr style="color: gray;">
													<td>name</td>
													<td>message</td>
													<td>date/time</td>
												</tr>
				<?php
					$receive=$conn->query("SELECT * FROM posts WHERE rid='$id'");
						while ($get=mysqli_fetch_array($receive))
						{
							$uid=$get['uid'];
							$msg=$get['msg'];
							$date=$get['date'];
							$print=$conn->query("SELECT * FROM chat WHERE id='$uid'");
							while ($gat=mysqli_fetch_array($print)) {
								$name=$gat['name'];
									?>
											<tr>
												<td><?php echo $name; ?></td>
												<td><?php echo $msg; ?></td>
												<td><?php echo $date; ?></td>
											</tr>
									<?php
							}
						}
				?>
			</table>
			</div>

	
	</div>

<form action="message.php" method="post">
	<div class="form-group">
	<select name="name">
		<?php
		$ft=$conn->query("SELECT * FROM chat ORDER BY id");
			while($ftt=mysqli_fetch_array($ft))
			{
		?>
		<option value="<?php echo $ftt['id']; ?>"><?php echo $ftt['name']; ?></option>
		<?php
			}
		?>
	</select></div>
	<div class="form-group">
	<textarea name="msg" placeholder="type here" ></textarea></div>
	<input type="submit" name="send" value="send" >
	
</form > 
<br>
<form action="logout.php">
	
	<input type="submit" value="logout" style="width: 100%; background-color: #6495ed; color: white; font-size: 20px;">
</form>

	</div>

</body>
</html>