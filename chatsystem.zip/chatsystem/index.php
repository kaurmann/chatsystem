<?php
session_start();
include 'conn.php';
if (isset($_POST['register'])) {
$name=$_POST['name'];
	$email=$_POST['email'];
	$password=$_POST['password'];
		$check=$conn->query("SELECT * FROM chat  WHERE name='$name'");
	$ar=mysqli_fetch_array($check);
	if ($ar) {
		echo "<script>alert('already exist');window.location.href='index.php';";
	}
	else
	{
	$ins=$conn->query("INSERT INTO chat (name,email,password) VALUES ('$name','$email','$password')");
	if ($ins) {
		echo "<script>alert('Register successfully');window.location.href='index.php';</script>";
	}
	else
	{
		echo "<script>alert('Sorry please check');window.location.href='index.php';</script>";
	}

	}
}


if (isset($_POST['Login'])) {
	$name=$_POST['name'];
	$password=$_POST['password'];
	$check=$conn->query("SELECT * FROM chat WHERE name='$name' && password='$password'");
	$ar=mysqli_fetch_array($check);
	if ($ar) {
		$_SESSION['admin']=$name;
		header('location:welcomechat.php');
	}else
	{
		echo "<script>alert('wrong id and password');window.location.href='index.php';";
	}
	}



?>
<!DOCTYPE html>


<html>
<head>
	<title>Chat system</title>
	<link rel="stylesheet" href="css/bootstrap.css"/>
<link rel="stylesheet" href="css/bootstrap.min.css"/>
<script src="js/bootstrap.js"></script>
<script src="js/jquery-1.11.0.js"></script>
<script src="js/bootstrap.min.js"></script>

</head>
<body>
	<div id="main" class="bg-info d-flex-center " style="height: 440px; width: 500px; border-radius: 30px; margin-left: 400px;  margin-top: 80px;">
		<div id="box" style="margin-left:20px;
	padding-top: 2px;">
			<h2>Register member login</h2>
	<form action="" method="post">
		<div class="form-group">
	<label>username</label>
	<input type="text" name="name"  placeholder= "name" required><br>
	</div>
	<div class="form-group">	
	<label>password</label>
	<input type="password" name="password"  placeholder= "password" required><br>
	</div>
	<input type="submit" name="Login" class="btn-success">
	 </form>

	 		<h2>sign up</h2>
	<form action="" method="post">
		<div class="form-group">
	<label>name</label>
	<input type="text" name="name" placeholder= "name" required><br>
		</div>
		<div class="form-group">
	<label >email/address</label>
	<input type="email" name="email" placeholder= "email" required=""><br>
		</div>
		<div class="form-group">
	<labe>password</label>
	<input type="password" name="password"  placeholder="password" required><br>
	</div>

	<input type="submit" name="register" class="btn-warning">
	 </form>

	</div>
	</div>
</body>
</html>